Diagnóstico de Dino Desktop. No incluye credenciales ni telemetría. El proyecto sólo se incluye si el usuario lo autorizó. Revise el contenido antes de compartirlo.
